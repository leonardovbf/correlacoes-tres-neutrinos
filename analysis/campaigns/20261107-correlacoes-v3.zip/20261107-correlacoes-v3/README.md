# Experimentos ampliados de correlações — 7 de novembro de 2026

Foram concluídas 36 configurações locais com 4, 6 e 8 qubits: três interações, dois estados iniciais e duas geometrias. A PSA usa a distribuição discreta completa, sem erro Monte Carlo. Cada configuração inclui 61 tempos e todos os pares e trios. Os três candidatos selecionados passaram por refinamento RK4 e comparação Qiskit–emulador.

Foram calculadas 54 matrizes densidade com ruído de portas e 108 condições de medição/leitura, cada uma com método bruto e mitigado sob orçamento igual de 81.920 shots por método. São 216 avaliações de métodos em condições exploratórias, não replicações independentes de hardware.

No perfil genérico p₂=0,001, p₁=0,0001 e leitura=0,03, os circuitos de dois passos apresentaram:

| Qubits | τ | Exato | PSA completa | Aer bruto | Redução do erro frente à PSA |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 4 | 0.55 | -0.685629 | -0.190083 | -0.510726 | 64.7% |
| 6 | 0.55 | 0.414548 | 0.136749 | 0.315412 | 64.3% |
| 8 | 0.65 | -0.130788 | 0.050202 | -0.083768 | 74.0% |

Todos esses pontos usam μ=10 e dois feixes antiparalelos, com acoplamentos normalizados para média fora da diagonal igual a 1. Em N=4, o estado inicial é de domínio; em N=6/8, alternado. Não são o mesmo ponto físico da confirmação v2 de quatro qubits.

![Comparação local](comparacao_local.png)

![Erro frente à PSA em função do ruído](erro_por_ruido.png)

D é o erro absoluto do circuito menos o erro absoluto da PSA. Valores negativos favorecem o circuito. A linha pontilhada mostra a previsão C₃=0: em N=8, até essa previsão supera a PSA, portanto D<0 isoladamente não demonstra recuperação da correlação. As faixas são IC95 pontuais e exploratórios, sob modelo estacionário de medições. O Aer usa despolarização genérica, não calibração IBM; a compilação genérica tem conectividade distinta da física. Os números não predizem a precisão no dispositivo nem estabelecem vantagem computacional.

## Execução IBM

Foram enviados 30 jobs, todos no `ibm_kingston`, com 368.640 shots: 20 blocos de confirmação v2 de quatro qubits, com 327.680 shots, e cinco blocos de cada tamanho N=6/8, com 40.960 shots no total. Os IDs e o estado nesta fotografia estão em [ibm_jobs.json](ibm_jobs.json). Estado resumido: `{'QUEUED': 30}`.

| Qubits da triagem v3 | Passos | Profundidade física | Portas de 2 qubits | Jobs |
| ---: | ---: | ---: | ---: | ---: |
| 6 | 2 | 540 | 204 | 5 |
| 8 | 2 | 927 | 429 | 5 |

Os circuitos QPY preparados são os enviados, com hashes e qubits físicos arquivados. A triagem v3 usa gate twirling com 32 randomizações × 128 shots por job. Os resultados físicos ainda dependem da conclusão dos jobs. A confirmação v2 conserva o ponto, a seleção e a regra originais; a triagem v3 é uma nova exploração.

## Controles e emendas

- Os 70 testes automatizados passaram. Novos controles verificam evolução livre, marginalização de bits, correção assimétrica de leitura, comparação de erros e prevenção de reenvio ambíguo.
- O maior desvio de C₃ no refinamento dos candidatos foi 2.94e-06. A maior diferença de probabilidades Qiskit–emulador foi 1.6e-15.
- A tolerância ideal original 0,001 selecionou circuitos mais longos. Uma emenda posterior à busca ideal definiu circuitos curtos com erro ideal ≤min(0,02; 10% da diferença PSA–exato), mantendo os candidatos originais. Os três casos selecionaram dois passos. O erro ideal de N=8 é aproximadamente 0,01285; não se afirma equivalência ao exato em ±0,01.
- O compilador de nível 3 falhou no controle estrito de equivalência com desvio de probabilidade 3,43×10⁻⁶. A tentativa e os fontes foram preservados em `data/compiler_level3_attempt/`. Outra emenda fixou nível 1, que passou no controle ideal de 10⁻¹⁰. A confirmação v2 mantém sua compilação original.
- Os critérios de seleção e o orçamento físico estão nos fontes dos protocolos. A seleção física usou os valores esperados locais e exigiu também distinguir C₃ de zero e superar a previsão nula no modelo. Não houve seleção a partir dos novos resultados IBM.

O objetivo alcançado localmente é maior precisão que a PSA em pontos selecionados. A evolução exata continua viável nesses tamanhos. Para demonstrar vantagem computacional, será preciso comparar tempo, memória e precisão com métodos clássicos competitivos numa escala maior, incluindo todos os custos quânticos. Ampliar qubits sem preservar o sinal não atende a esse objetivo.

## Reproduzir e acompanhar

Na raiz do repositório, os comandos locais retomam resultados completos sem recalculá-los:

```sh
.venv/bin/python scripts/run_correlation_search.py run
.venv/bin/python scripts/run_correlation_noise.py
.venv/bin/python scripts/run_correlation_short_noise.py run
```

Consultar os jobs já enviados não cria novos jobs:

```sh
.venv/bin/python scripts/prepare_short_circuit_experiments.py collect-hardware --record results/protocols/20261107T233046Z-6d048a1b4b85/run.json
.venv/bin/python scripts/run_correlation_hardware.py collect
```

O diretório `data/` contém os momentos agregados, contagens simuladas, probabilidades ruidosas, circuitos, metadados físicos e relatórios desta campanha. `sources/` preserva os novos scripts e protocolos; o motor usado pela busca está em `data/sources/`. O manifesto registra hashes dos arquivos desta fotografia. O registro completo dos 20 jobs v2 continua em `results/`.
