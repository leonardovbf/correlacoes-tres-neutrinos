# Resultados IBM concluídos — 8 de novembro de 2026

Os 30 jobs terminaram: vinte de confirmação N=4 e cinco de cada triagem N=6/8. Foram verificadas 368.640 contagens de medição, IDs distintos, orçamento por job e hashes dos circuitos da triagem. Esta análise não enviou novos jobs.

O resultado físico favorece menor erro que a PSA nos três pontos principais. O teste de confirmação de N=4 passou na regra original; N=6/8 permanecem pilotos exploratórios de cinco blocos. Isso demonstra ganho de precisão relativo à PSA nesses pontos, sem estabelecer vantagem computacional quântica.

| Qubits | C₃ exato | C₃ PSA do protocolo | C₃ IBM | Redução do erro absoluto |
| ---: | ---: | ---: | ---: | ---: |
| 4 | -0.158685 | -0.052145 | -0.097087 | 42.2% |
| 6 | 0.414548 | 0.136749 | 0.194897 | 20.9% |
| 8 | -0.130788 | 0.050202 | -0.022495 | 40.2% |

![Resultados físicos IBM](comparacao_ibm.png)

A faixa sombreada é ±0,01 em torno do exato. As barras IBM são IC95 de reamostragem de jobs. Em N=4 a tabela usa a PSA amostrada do protocolo original; N=6/8 usam a distribuição completa da PSA. Os pontos físicos são distintos: N=4 usa μ=3,τ=1,5 e acoplamento uniforme; N=6/8 usam μ=10, dois feixes e τ=0,55/0,65. Portanto, as diferenças entre linhas não isolam o efeito de N.

## Confirmação e incerteza

A análise original N=4 foi reproduzida a partir das contagens e dos momentos PSA arquivados, com concordância numérica de 10⁻¹³. Sua decisão é `supports_better_than_psa_at_this_endpoint`: D≈−0,044943 e IC95 [−0,052047;−0,037785]. O intervalo de IBM−PSA também exclui zero.

Como sensibilidade, foram usados 10.000 sorteios apenas de blocos independentes de jobs e, separadamente, multinomial estacionário. A PSA completa foi usada como referência clássica sem erro Monte Carlo, inclusive em N=4. Essas sensibilidades não substituem a decisão e os intervalos originalmente definidos:

- N=4: D=-0.044943; IC95 por blocos, usando PSA completa: [-0.046290; -0.039183].
- N=6: D=-0.058149; IC95 por blocos, usando PSA completa: [-0.073694; -0.042578].
- N=8: D=-0.072697; IC95 por blocos, usando PSA completa: [-0.081023; -0.064640].

Todos os intervalos de D dessas duas sensibilidades ficaram abaixo de zero. Os intervalos IBM de C₃ excluem zero e os contrastes de erro contra a previsão C₃=0 também favorecem a IBM. Nos pilotos, cinco jobs permitem apenas uma avaliação limitada de deriva e cobertura dos intervalos.

O sinal N=8 é negativo, como o exato, mas sua amplitude absoluta equivale a aproximadamente 17.2% da referência. O circuito preservou um sinal detectável, ainda fortemente atenuado. O erro físico N=8 é maior que o previsto no Aer genérico; os 74% de redução mencionados anteriormente eram da simulação, enquanto a redução física foi 40.2%.

Nenhum dos três pontos recuperou o exato dentro da margem ±0,01. Os erros absolutos IBM são 0.061597, 0.219650 e 0.108293. Mais precisão que a PSA e equivalência ao exato são afirmações diferentes. As contagens são brutas com gate twirling; não foi aplicada correção de leitura aos novos dados físicos.

## Análise secundária de todos os trios

Após a coleta, foram examinados todos os trios disponíveis no mesmo instante. A tabela compara estimativas pontuais e RMSE entre trios, usando PSA completa. É uma análise posterior e exploratória: as contagens de trios melhores não representam esse número de detecções confirmatórias independentes.

| N | Trios com menor erro pontual IBM que PSA | RMSE IBM | RMSE PSA | Redução do RMSE |
| ---: | ---: | ---: | ---: | ---: |
| 4 | 2/4 | 0.078996 | 0.096196 | 17.9% |
| 6 | 17/20 | 0.098800 | 0.117763 | 16.1% |
| 8 | 56/56 | 0.059595 | 0.096625 | 38.3% |

Os dados completos estão em [analysis.json](analysis.json), [primary.csv](primary.csv) e [secondary_trios.csv](secondary_trios.csv). A reamostragem preserva simultaneamente todos os trios de cada job. Não houve exclusão de blocos nem seleção de um novo alvo principal depois de observar os resultados físicos.

## Dados e reprodução

`raw/` contém contagens de N=4, momentos PSA por bloco, dados da triagem N=6/8, circuitos QPY e metadados. `reference_endpoints.npz` preserva as referências por trio. Os relatórios oficiais são copiados sem alterações, e `sources/` contém o analisador e fontes numéricos relevantes. O manifesto registra hashes de todos os arquivos e as origens dos dados.

Para gerar outro pacote sem sobrescrever esta fotografia:

```sh
MPLCONFIGDIR=/private/tmp/neutrinos-matplotlib-cache PYTHONPATH=src .venv/bin/python analysis/analyze_completed_ibm.py --output analysis/campaigns/NOVO-PACOTE
```

O passo científico seguinte é confirmar independentemente os pontos de seis/oito qubits, controlar erros de portas/leitura e comparar custo e precisão com métodos clássicos competitivos. Aumentar o número de qubits isoladamente não constitui evidência de vantagem computacional.
