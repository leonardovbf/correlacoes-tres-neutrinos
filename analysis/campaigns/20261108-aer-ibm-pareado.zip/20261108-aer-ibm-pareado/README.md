# Comparação Aer–IBM pareada — 8 de novembro de 2026

O Aer foi reexecutado localmente a partir dos programas dos 30 jobs IBM concluídos. Foram mantidos os pontos físicos, circuitos nativos arquivados, mapeamento físico e clássico, gerador e política de twirling, shots por randomização, blocos e processamento bruto. Nenhum novo job IBM foi enviado.

| N | Exato | Aer calibrado | Aer calibrado + ócio ASAP | IBM existente |
| ---: | ---: | ---: | ---: | ---: |
| 4 | -0.158685 | -0.081481 | -0.077819 | -0.097087 |
| 6 | 0.414548 | 0.172019 | 0.140992 | 0.194897 |
| 8 | -0.130788 | -0.012498 | 0.010108 | -0.022495 |

![Comparação pareada](paired_comparison.png)

A faixa sombreada é ±0,01 do exato. Os intervalos são reamostragens dos blocos de jobs, com medições Aer e IBM independentes. Não incluem incerteza dos parâmetros de calibração nem viés do modelo de ruído. N=6/8 têm apenas cinco blocos cada, o que limita a avaliação de variabilidade. O cenário com ócio é uma sensibilidade de escalonamento, não uma recuperação do cronograma real de pulsos.

## O que foi efetivamente igualado

- Os 20 jobs N=4 usam o ponto μ=3,τ=1,5, acoplamento uniforme e estado de domínio; N=6/8 usam seus pontos de dois feixes, μ=10,τ=0,55/0,65 e estado alternado. A comparação não mistura o exemplo local v3 de N=4 com a confirmação v2.
- Cada job N=4 tem 32 randomizações × 512 shots; cada job N=6/8 tem 32 × 128. Totais por cenário: 327.680, 20.480 e 20.480, os mesmos da IBM. Cinco cenários locais perfazem 1.843.200 shots simulados.
- Foram baixados, por leitura dos jobs existentes, os próprios QuantumPrograms e Samplex do Runtime. Assim, são reproduzidas também as rotações de um qubit introduzidas pelo mecanismo de twirling. O programa nativo executável pode ter mais operações que o QPY base.
- Não houve nova transpilação do circuito lógico. A remoção de fios ociosos do registrador de 156 posições conserva as portas, qubits físicos ativos e permutação dos bits medidos. Os arquivos originais e seus hashes são mantidos.
- Os dois ambientes são comparados sem correção de leitura e com gate twirling. Não se coloca um Aer mitigado contra um IBM bruto.
- As calibrações são as arquivadas com os jobs/preparação original. Não foram escolhidos parâmetros para ajustar a simulação aos resultados físicos.

O programa com twirling recuperado contém mais rotações físicas de um qubit que o circuito base. Estas são contagens de operações nos arquivos, antes de eventuais simplificações internas de pulsos não registradas:

| N | CZ, base e template | SX no QPY base | SX no template Runtime |
| ---: | ---: | ---: | ---: |
| 4 | 78 | 199 | 614 |
| 6 | 204 | 489 | 1674 |
| 8 | 429 | 999 | 4042 |

O replay inclui o template completo; simular apenas o QPY base com ruído não representaria a mesma sequência programada.

## Limites do pareamento

As opções e os programas recuperados não informam a semente aleatória interna usada pelo servidor para sortear cada instância de twirling. O replay usa o mesmo Samplex, política, número de variantes e orçamento, com novas sementes locais registradas e parâmetros amostrados arquivados. Portanto, pareia-se a distribuição do procedimento, não se afirma repetir a mesma sequência aleatória física.

O ruído real também não é copiável integralmente de um snapshot. O modelo calibrado usa erros de portas derivados por `basic_device_gate_errors` do Aer, relaxação T₁/T₂ durante as portas, erro independente de inicialização e matriz de leitura assimétrica por qubit. Assume temperatura de equilíbrio zero. A frequência física não consta do snapshot e não foi inventada: nessa hipótese a população térmica excitada é zero independentemente dela.

Os canais de inicialização/leitura são tratados como independentes, uma aproximação de SPAM. Não há um modelo completo de erros coerentes, vazamento, crosstalk ou deriva entre a calibração e a execução. A data da calibração e os tempos dos jobs estão nos dados arquivados.

O modelo principal aplica relaxação durante portas. Foi acrescentada uma sensibilidade com relaxação nos tempos ociosos calculados por um cronograma ASAP hipotético, com durações de portas e barreiras arquivadas. O cronograma real de pulsos do hardware não está nos programas; esse cenário não deve ser tratado como uma reprodução medida dos tempos ociosos.

## Separação das fontes de erro

![Ablation de ruído](noise_ablation.png)

Os cinco cenários usam as mesmas 32 variantes locais em cada bloco: ideal; apenas leitura; erros de portas com relaxação; modelo completo incluindo inicialização/leitura; completo com ócio ASAP. As contagens de cada cenário são amostradas independentemente, mantendo o orçamento físico. A ablação é uma interpretação do modelo calibrado, não prova causal de cada erro do chip.

Os pontos azuis e seus intervalos usam contagens finitas, comparáveis ao orçamento IBM. Os diamantes laranja usam as probabilidades simuladas antes da amostragem de shots. Para interpretar o efeito sistemático dos canais, estas últimas previsões são:

| N | Ideal | Apenas leitura | Portas/relaxação | Completo | Completo + ócio ASAP |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 4 | -0.157860 | -0.144122 | -0.090205 | -0.081078 | -0.078206 |
| 6 | 0.415834 | 0.398603 | 0.163626 | 0.155844 | 0.141916 |
| 8 | -0.117940 | -0.106933 | -0.022093 | -0.019760 | -0.015724 |

Em N=8 com ócio ASAP, o sinal da estimativa amostrada muda para positivo, enquanto a previsão probabilística permanece negativa. Essa diferença é flutuação dos shots locais fixados no plano; não é uma inversão determinística causada pelo canal de relaxação. As sementes e as contagens foram mantidas, sem repetir o sorteio para aproximar a IBM. As previsões sem shots também preservam apenas as 32 variantes de twirling por job, não uma média sobre todas as randomizações possíveis.

Mesmo sem ruído, o circuito de dois passos aproxima a evolução exata. Usando as probabilidades ideais, sem flutuação de shots:

- N=4: circuito ideal com dois passos C₃=-0.157860; referência exata=-0.158685; diferença de discretização=+0.000824.
- N=6: circuito ideal com dois passos C₃=0.415834; referência exata=0.414548; diferença de discretização=+0.001286.
- N=8: circuito ideal com dois passos C₃=-0.117940; referência exata=-0.130788; diferença de discretização=+0.012848.

Diferenças residuais do modelo completo para o hardware:

- N=4: IBM−Aer=-0.015607, IC95 por blocos [-0.020613; -0.010859].
- N=6: IBM−Aer=0.022879, IC95 por blocos [0.000005; 0.047551].
- N=8: IBM−Aer=-0.009997, IC95 por blocos [-0.027079; 0.007717].

O objetivo deste replay é validar e qualificar a previsão do simulador. Não é um novo teste confirmatório de superioridade, nem altera os dados físicos ou a decisão original IBM–PSA.

O modelo aponta as portas e a relaxação como a principal perda prevista de sinal, acima da leitura isolada. A prioridade técnica é reduzir operações físicas/profundidade e validar o modelo com calibrações próximas da execução; ampliar shots melhora a incerteza estatística, mas não corrige esse viés. A sensibilidade ASAP não foi escolhida como modelo vencedor a partir da proximidade dos dados IBM.

## Controles e reprodutibilidade

O maior desvio entre as probabilidades ideais do template Runtime e o QPY base foi 3.69e-07; entre C₃ de todos os trios, 7.82e-07. O controle inicial mais estrito de 10⁻⁹ falhou no primeiro template com diferença de 1,39×10⁻⁷ e foi preservado em `attempts/ideal_control_v1`. Como o objetivo é reproduzir o programa Runtime efetivamente enviado, não o resintetizar, validou-se adicionalmente C₃ no limite numérico de 10⁻⁵ já adotado no estudo, 0,1% da margem de equivalência de 0,01. O histórico dessa emenda está no plano e no arquivo de dados.

Os seis testes novos verificam o mapeamento de bits após compactação, a assimetria da leitura, canais calibrados sem frequência, relaxação ociosa analítica, inicialização e rejeição de medições não terminais. A suíte completa passou: 76 testes (`PYTHONPATH=src .venv/bin/python -m unittest discover -s tests -v`). Durante o replay, cada orçamento e cada equivalência são checados em todos os jobs e variantes.

- [comparison.csv](comparison.csv): valores, erros e diferenças para cada cenário.
- [analysis.json](analysis.json): intervalos e metadados da comparação.
- [matching_controls.csv](matching_controls.csv): orçamento, índices físicos e controles por job.
- [validation.json](validation.json) e [test_output.txt](test_output.txt): resultado e saída da suíte de testes.
- `replay_data.zip`: programas recuperados, QPY base e templates compactos, calibrações, contagens físicas, sementes/parâmetros locais, probabilidades simuladas e tentativas preservadas.
- `sources/`: código e ambiente de referência; `manifest.json`: hashes dos arquivos.

Para retomar o replay local completo, sem rede e sem novos jobs:

```sh
PYTHONPATH=src .venv/bin/python analysis/run_paired_aer.py
```

Para exportar outro pacote, preservando este:

```sh
MPLCONFIGDIR=/private/tmp/neutrinos-matplotlib-cache .venv/bin/python analysis/package_paired_aer.py --output analysis/campaigns/NOVO-PACOTE
```

Referências técnicas: [modelo de ruído Aer](https://qiskit.github.io/qiskit-aer/stubs/qiskit_aer.noise.NoiseModel.html) e [opções de twirling IBM](https://quantum.cloud.ibm.com/docs/en/api/qiskit-ibm-runtime/options-twirling-options).
